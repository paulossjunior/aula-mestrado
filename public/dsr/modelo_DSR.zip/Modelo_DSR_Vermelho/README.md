# Modelo DSR para dissertações

Este projeto LaTeX foi construído tomando como referência a organização da parte de Design Science Research da tese fornecida pelo orientador.

O arquivo `capitulos/metodo-dsr.tex` reproduz a lógica da seção **Research Method** da tese: apresentação da DSR, Ciclo de Relevância, Ciclo de Design e Ciclo de Rigor. O texto já está escrito como uma narrativa acadêmica e os trechos marcados com **[PREENCHA: ...]** indicam o conteúdo que deve ser substituído pelo aluno.

O arquivo `capitulos/learning-iterations.tex` segue a organização do capítulo **Learning Iterations Towards Immigrant**, com uma seção para cada Learning Iteration, apresentação do estudo, execução e resultados, ameaças à validade quando pertinentes e a seção **O que aprendemos?**. O aluno deve duplicar ou remover iterações conforme o desenho da própria pesquisa.

O arquivo `capitulos/final-learning-iteration.tex` segue a lógica do capítulo de avaliação final da tese: contexto, planejamento do estudo, execução/coleta/resultados, discussão, ameaças à validade, **O que aprendemos?** e considerações finais.

O modelo foi deliberadamente escrito em texto corrido. Requisitos e critérios aparecem integrados à narrativa, em vez de listas. A intenção é que o estudante use o arquivo como uma estrutura de escrita e não como um formulário de tópicos.

Para utilizar no Overleaf, envie toda a pasta ou o arquivo ZIP e compile `main.tex`. Ao finalizar uma seção, substitua todos os campos `\preencher{...}` pelo texto definitivo.
